const openDoor = () => {
    alert("On April 21st 2020, medicine student, Ambrosia Van-Helsing had been reported missing from her family home in the city of Transylvania. Ambrosia was last seen with her boyfriend, Drake Silas, in Transylvania city centre, where they went out to hang out at the Meat and Bones Diner.  Drake had also disappeared that same day.");
    alert("The following day, Ambrosia’s very close friend, Vladimir Cullen, a student detective at the same university, received a text from a private number telling him to come to a suspicious address on the outskirts of Transaylvania if he ever wants to see Ambrosia again. Vladimir’s immediate reaction is that it may be a really bad prank. However, he heads to his car and begins his journey to go and save Ambrosia.");
    alert("NOTICE WARNING: WELCOME TO THE RESIDENCE OF COUNT DRACULA. BY ENTERING 159 TRANSYLVANIA ESTATE YOU AGREE THAT YOU ARE PERSONALLY LIABLE FOR YOUR OWN SAFETY. THE OWNER OF THIS PREMISES CANNOT BE HELD RESPONSIBLE. IF YOU ARE UNHAPPY WITH THIS, TURN AWAY NOW OR FOREVER HOLD YOUR PEACE. HOWEVER, IN CASE YOU’RE FEELING REALLY BRAVE, BE PREPARED TO FIGHT OR BREAK OUT!")
    alert("Vladimir: Count Dracula?... I'm suddenly beginning to feel chills going down my spine... The hairs on the back of my neck standing... Mountains of goosebumps all over my skin... Maybe these are all signs warning me to turn back... That this is a BAD IDEA!");
    alert("Vladimir: Psst, SNAP OUT OF IT VLAD! Just a massive, weird, creey house... with a hearse parked in the front... and a graveyard... NO BIGGIE!");
    alert("Vladimir: It is just a BIG HOUSE and Ambrosia is still in GRAVE DANGER! I MUST SAVE HER! No matter what Dracula has in store for me!");
    let doorOpen = prompt ("GREAT! It seems the gates are locked! How will I get it open? [Climb Over/Scream/Look Under Door Mat/Shout OPEN SESAME!]");
    switch(doorOpen) {
        case "Look Under Door Mat":
        case "Look under door mat":
        case "look under door mat":
            alert("YES! There is a key! This must open the both the gate and the door... GREAT! It works! AMBROSIA, HERE I COME");
            startGame();
            break;
            default:
            alert("It seems that no one is going to answer! Let's Try Again");
            openDoor();
            break;
    }
}

const startGame = () => {
    alert("Vladimir begins walking through the graveyard in search for his friend Ambrosia");
    alert("Vladimir: I always got a weird vibes from that Drake guy... Maybe he has something to do with this!");
    alert("The ground begins to shake abruptly...");
    alert("Vladimir: WHAT THE HELL!... ARE THOSE ZOMBIES!");
    alert("Vladimir runs for towards hearse... He looks inside and finds a bag filled with weapons on the drivers seat");
    alert("Vladimir: OH NO, They're coming closer! There must be something in here that will take them all out!");
    let defZombie = prompt("What weapon should Vladimir use to defeat the Zombies? [Grenade/Cross/Gun and silver bullets/Stake]");
    switch(defZombie) {
        case "Grenade":
        case "grenade":
            alert("Vladimir throws the grenade and takes cover inside the hearse. The Zombies have all been blown to pieces. He proceeds");
            wereWolf();
            break;
        case "Gun and silver bullets":
        case "gun and silver bullets":
            alert("There was only enough bullets loaded to kill one Zombie... The rest are still on their way to eat your brains. Let's Try again");
            startGame();
            break;
        case "Cross":
        case "cross":
            alert("I don't think an exorcism is going to work against Zombies... They already have no soul. Let's Try Again");
            startGame();
            break;
        case "Stake":
        case "stake":
            alert("You need to be skilled to get close and kill an army of Zombies... Well you're not, they will eat you alive if you get too close. Let's Try Again");
            startGame();
            break;
            default:
                alert("Check spelling of the weapon you have chosen and try again");
                startGame();

    
    }
}

const wereWolf = () => {
    alert("Vladimir begins running towards the house but notices one of the Zombies were still growling on the floor, half blown up");
    alert("Vladimir: Dr. Frankenstein!? My old Biology teacher. You're a... You're a Zombie?!")
    alert("Vladimir continues to run towards the house. As he enters there seems to be a howling noise coming from within the house");
    alert("Vladimir: Is that a Werewolf?... Great. I'm definitely not making it out of here alive... Maybe if I creep in slowly it won't notice me");
    alert("However, the Werewolf had already heard Vladimir blowing up Zombies... It begins running towards him");
    let defWolf = prompt("Vladimir: OH NO! It must've smelt me. I need to take it out! What weapon should I use this time? [Frisby/Cross/Gun and silver bullets/Stake]");
    switch(defWolf) {
        case "Frisby":
        case "frisby":
            alert("Vladimir throws the frisby... He must've forgot he is in battle, this isn't the park! Let's Try Again");
            wereWolf();
            break;
        case "Cross":
        case "cross":
            alert("I don't think an exorcism is going to work against Zombies... They already have no soul. Let's Try Again");
            wereWolf();
            break;
        case "Gun and silver bullets":
        case "gun and silver bullets":
        case "Gun":
        case "gun":
            alert("Vladimir: HEADSHOT!!!!");
            alert("The Werewolf begins to shrink back into its human form");
            alert("It transforms into Ambrosia's boyfriend... DRAKE");
            alert("Vladimir: DRAKE!? I KNEW IT! Possessive little sh... That explains the suspicious text from earlier. YOU WANTED TO KILL ME!");
            alert("Vladimir continues through the house");
            ghost();
            break;
        case "Stake":
        case "stake":
            alert("You need to be skilled to get close and kill a Werewolf instantly... Well you're not, the Werewolf has superhuman strength and the aggression of a Lion, you'll be shreaded to pieces. Let's Try Again");
            wereWolf();
            break;
            default:
                alert("Check spelling of the weapon you have chosen and try again");
                wereWolf();

    }
}

const ghost = () => {
    alert("Vladimir: I can't believe Drake turned out to be a bloody Werewolf. I always knew he was a nutter but a DAMN WEREWOLF!");
    alert("Vladimir: Quite ironik that his debut single was Thriller feat. Michael Jackson!... I finally understand where the idea for the video came from");
    alert("Vladimir: Oh well! At least now I can finally declare my love for Ambrosia");
    alert("Suddenly, a gust of air violently throws Vladimir to the ground");
    alert("He immediately looks into his bag of weapons to see what he could use to defeat...");
    alert("...Well that's the thing, he doesn't seem to know what knocked him to the ground, until...");
    alert("Vladimir: GREAT! A FRICKING GHOST!... A GHOST!");
    alert("The ghost introduces himself at Caspernella the unfriendly Vampire ghost, a servent of Count Dracula");
    alert("She explains that Count Dracula promised to give Ambrosia's body to Caspernella so that she can come back to life");
    alert("However, this will only happen Count Dracula can use Vladimir's to bring his son back to life");
    alert("Vladimir: Wait... Why does he want my body? Furthermore, how does he even know me?");
    alert("Vladimir: Anyway! This is getting quite boring now! You speak too much! It's time to get rid of you, FOR GOOD");
    let defGhost = prompt("What could Vladimir use to get rid of Caspernella the unfriendly Vampire ghost for good? [Frisby/Cross/Gun and silver bullets/Stake]");
    switch(defGhost) {
        case "Frisby":
        case "frisby":
            alert("Vladimir throws the frisby... He must've forgot he is in battle. On top of that, this is a ghost, it'll go straight through! Let's Try Again");
            ghost();
            break;
        case "Cross":
        case "cross":
            alert("Vladimir starts praying. He is performing an excorcism. Caspernella the unfriendly Vampire ghost has been excorcised!");
            alert("Vladimir: ...What the hell just happened? Good thing! I'm a Christian, I can only imagine what she would be capable of doing if she managed to possess me");
            alert("Vladimir: To be honest, the real question is why Count Dracula wants MY body?!")
            bats();
            break;
        case "Gun and silver bullets":
        case "gun and silver bullets":
            alert("The gun is empty. There was only one bullet which was used on Drake the Werewolf. Furthermore, this is a ghost, it'll go straight through! Let's Try Again");
            ghost();
            break;
        case "Stake":
        case "stake":
            alert("Caspernella may have been a Vampire in her lifetime but she is now just a ghost... There's nothing to stab, it'll go straight through. Let's Try Again");
            ghost();
            break;
            default:
                alert("Check spelling of the weapon you have chosen and try again");
                ghost();
    }
}

const bats = () => {
    alert("Vladimir starts to notice blood on the floor leading a door down the hallway.");
    alert("Vladimir opens the door and walks into a room that is pitch black");
    alert("He brings out his phone to use the flash light but hears a loud screech!");
    alert("A swarm of bats begin to flap their wings vigorously as they notice Vladimir with the flash light in his hand");
    let defBats = prompt("Vladimir: I don't think my bag of weapons will do the trick this time round. I need these bats to disperse IMMEDIATELY! What could I possibly do? [Throw his shoe/Shout stop/Open the curtains/Turn on the radio]");
    switch(defBats) {
        case "Throw his shoe":
        case "throw his shoe":
            alert("Vladimir throws his shoe... There are too many bats, they'll still be blood thirsty! Let's Try Again");
            bats();
            break;
        case "Shout stop":
        case "shout stop":
            alert("The bats answer only to the command of Count Dracula, Vladimir stands no chance. Let's Try Again");
            bats();
            break;
        case "Open the curtains":
        case "open the curtains":
            alert("Great! The bats have been weakend by the sunlight. They disperse and gather under the remainder of the shade in the room");
            alert("This attack seems to have also weakend Count Dracula, who had been standing in the dark between two coffins during the attack. The identity of the man who wants Vladimir's body is finally revealed");
            alert("Vladimir: I can't believe what I am seeing... This can't be");
            countDracula();
            break;
        case "Turn on the radio":
        case "turn on the radio":
            alert("The bats were rattled by the sound of the radio and attacked Vladimir viciously attacked! There was nothing left when they were finished with him. Let's Try Again");
            bats();
            break;
            default:
                alert("Check spelling of the weapon you have chosen and try again");
                bats();  
    } 
}

const countDracula = () => {
    alert("Vladimir: So Mr. Buffy, YOU are Count Dracula?... What the actually hell? What's this all about? Why have you done this?!");
    alert("Count Dracula: YES! You don't know how long I've been waiting for this. You are the reason my life has been shattered to pieces!");
    alert("In June 2018, Vladimir worked on a case during his first few years as a student detective.");
    alert("A serial killer who has all killed Mr. Buffy's son");
    alert("Vladimir eventually infiltrated the target's location and had given it to superior. The accused was sentenced to death");
    alert("Count Dracula: You got my son killed... An innocent young man... He didn't mean to kill all those people. He was going through his first stage of Vampire transformation");
    alert("Vladimir: Well I only found out Vampires existed today so... I'm sorry if I didn't take that into consideration when innocent people were killed...Just let Ambrosia go, I am here now");
    alert("Count Dracula: NOOOOOOOO! YOU AND GIRL BOTH DIE! NO ONE HAS EVER LEFT TRANSYLVANIA ESTATE ALIVE");
    let defDracula = prompt("Vladimir is in trouble, what weapon could he use from his bag of weapons to defeat Count Dracula. He has also been weakend by the sunlight [Frisby/Nunchucks/Phone/Stake]");
    switch(defDracula) {
        case "Frisby":
        case "frisby":
            alert("Vladimir throws the frisby... He must've forgot he is in battle, this isn't the park! Let's Try Again");
            countDracula();
            break;
        case "Nunchucks":
        case "nunchucks":
            alert("Vladimir is inexperienced using nunchucks... Furthermore, although Count Dracula has been weakend, the is still capable of defeating a human with nunchucks. Let's Try Again");
            countDracula();
            break;
        case "Phone":
        case "phone":
            alert("That would be stupid! The police couldn't even find Ambrosia to begin with, I doubt that would be able to contain a creature like Count Dracula");
            countDracula();
            break;
        case "Stake":
        case "stake":
            alert("Vladimir: EUREKA! THAT'S IT! I DID IT HE'S DEAD!");
            alert("Vladimir: VLADIMIR MATE! You've definitely outdone yourself this time lad!");
            alert("Vladimir: Mr. Buffy... Me and Ambrosia's favourite primary school teacher... It's sad to see that he couldn't understand his son was a murder...");
            alert("Vladimir: Oh yeah. AMBROSIA!");
            breakOut();
            break;
            default:
                alert("Check spelling of the weapon you have chosen and try again");
                countDracula();  
    }
}
const breakOut = () => {
    alert("Vladimir: She has to be in one of these two coffins... But I have to be careful, Mr. Buffy's could have become a vampire ghost");
    alert("Vladimir: If i open the wrong coffin, he would potentially possess the body... I better bring out the cross");
    alert("Coffin 1 has dust all over it, doesn't seem to have been opened in years. Coffin 2 has a hand print and sheds of werewolf hair all around. Coffin 3 is covered in blood! Both dry and wet!");
    let breakOutFinale = prompt("What coffin is Ambrosia most likely to be in? I hope Mr. Buffy didn't harm her!");
    switch(breakOutFinale) {
        case "Coffin 1":
        case "Coffin One":
        case "coffin 1":
        case "coffin one":
        case "1":
        case "one":
            alert("You  have awoken another vampire! We will never leave here!");
            breakOut();
            break;
        case "Coffin 2":
        case "Coffin Two":
        case "coffin 2":
        case "coffin two":
        case "2":
        case "two":
            alert("Valdimir: Count Dracula basically left his print all over this!");
            alert("Vladimir: The hair must be from Drake when he turned into a werewolf");
            alert("Vladimir: OMG! THANK GOD! AMBROSIA! YOU ARE ALIVE!!!!")
            alert("Vladimir: You would never believe everything I've been through, HONESTLY! But first.. Let's get outta here!")
            alert("After Vladimir had told Ambrosia everything that happened, he decided not to declare his love for her. He felt as if he was the reason Mr. Buffy took her in the first place. He could bear to ever see her in danger again. The End")
            ambrosiaSafe();
            break;   
        case "Coffin 3":
        case "Coffin Three":
        case "coffin 3":s
        case "coffin three":
        case "3":
        case "three":
            alert("You have awoken Mr Buffy's son vampire! We will never leave here!");
            breakOut();
            break; 
            default:
                alert("Check spelling of the weapon you have chosen and try again");
                countDracula();  
    }
}